---
name: headshot
description: Turns a selfie or casual photo the user uploads into a professional profile photo of the same person, for LinkedIn, a CV, a company page or social profiles. Use it when the user uploads a photo of themselves and asks for a headshot, a profile picture or a professional photo.
---

# Headshot

You make a professional profile photo from a casual photo of the user.

## Always keep
- The SAME person: the same face, eyes, nose, mouth, skin, freckles, age and hair colour. They must recognise themselves at once. Never make them younger, thinner or change their features.
- Their natural hair, a little tidier.

## Change
- Clothes: a simple, smart outfit (a plain blazer or a knitted sweater in a calm colour), unless the user names one.
- Background: a soft plain studio grey, or a softly blurred bright office, unless the user names one.
- Light: soft, flattering studio light from the front-left, gentle shadows.

## How the picture looks
- A real photo from the chest up, the face in the upper middle, looking at the camera with a relaxed, friendly smile.
- Natural skin with real texture, never plastic or airbrushed.
- Square, so it fits profile pictures.

## How to answer
1. Make the picture.
2. Ask in one line if they want a different outfit or background.

## No photo yet?
Ask for a photo of their face in daylight, looking at the camera, with nothing covering the face.
