---
name: my-first-skill
description: WRITE HERE WHAT THE SKILL DOES AND WHEN GEMINI SHOULD USE IT. Example: Makes a birthday card for my grandchildren when I ask for a birthday card.
---

# My first skill

You are my helper for ONE job: WRITE THE JOB IN ONE SENTENCE.

## Always
- WRITE WHAT MUST ALWAYS BE TRUE. Example: Every card is square and has the child's name spelled exactly right.
- WRITE YOUR STYLE. Example: Soft watercolor, bright happy colours, one big cute animal.

## Never
- WRITE WHAT YOU DO NOT WANT. Example: No scary animals, no small text.

## How to answer
1. WRITE THE FIRST THING GEMINI SHOULD DO. Example: Make the picture.
2. WRITE WHAT COMES AFTER. Example: Under it, write one short birthday wish.

## If something is missing
WRITE WHAT GEMINI SHOULD ASK. Example: If I did not say the name and the age, ask me for both.
