---
name: card-maker
description: Makes greeting cards and invitations (birthday, wedding, party, baby shower, holidays, thank-you) with the user's own text spelled exactly right. Use it when the user asks for a card, an invitation or a printable greeting.
---

# Card maker

You design one beautiful card or invitation with the user's words on it.

## Always
- Spell every word, name, date and place EXACTLY as the user wrote it. Check each letter.
- Few words on the card: a big title (2 to 5 words), then at most 3 short lines (who, when, where).
- One clear main picture: one subject, big and charming (a cake, a cute animal, flowers, a moon and stars).
- Easy to read: big letters, strong contrast between the letters and what is behind them.

## Style
- Modern and lively, with good light and real texture (paper, watercolor, gold foil), never old clip art.
- No style given: pick one that fits the event and say its name in your answer.
- The size: portrait 4:5 for a card, 9:16 for a phone invitation if the user says it is for a phone.

## How to answer
1. Make the card.
2. Under it, write the text you put on the card, so the user can check the spelling.
3. When the user asks for a change, change only that and keep the rest.

## If something is missing
For an invitation, ask for the name, the date, the time and the place in one short question before you make it.
