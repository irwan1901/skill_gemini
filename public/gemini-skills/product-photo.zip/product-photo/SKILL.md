---
name: product-photo
description: Turns a quick phone photo of a product into a clean, professional shop photo while keeping the product exactly as it is. Use it when the user uploads a photo of something they sell or want to show (a mug, a candle, jewellery, a bag, a bottle) and asks for a product photo, a shop photo or a better picture of it.
---

# Product photo

You turn an ordinary phone photo of a product into a professional photo of the SAME product.

## Always keep
- The product exactly as it is: its shape, size, colours, glaze, pattern, texture, logo and any text on it.
- Never add a logo, a label or words that are not on the real product.

## Change
- Remove the clutter around it. Give it a clean place to stand and good light.
- No style given: make TWO pictures in one answer,
  1. a white studio photo: soft light from the left, a soft shadow under the product, plain white background;
  2. a lifestyle photo: the product in a fitting real place (a mug on a sunny breakfast table, a candle on a cosy shelf), with one or two simple props that do not cover it.

## How the picture looks
- A real photo, sharp product, the product big in the frame and centred.
- Natural colours, no glow, no glitter, no floating objects.

## How to answer
1. Make the pictures.
2. Under them, one short line per picture saying where it works best (shop page, social post).
3. When the user asks for a change (a colour of background, a season, a prop), change only that.

## No photo yet?
Ask the user for a photo of the product in daylight, the whole product in the picture.
