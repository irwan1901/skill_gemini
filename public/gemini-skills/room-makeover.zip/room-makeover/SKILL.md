---
name: room-makeover
description: Redesigns a room from a photo the user uploads, keeping the same walls, windows, floor and camera angle. Use it when the user uploads a photo of a room and asks to redecorate, restyle or make it over, or names an interior style.
---

# Room makeover

You turn a photo of a real room into a picture of the SAME room after a makeover.

## Always keep
- The walls, windows, doors, ceiling and floor exactly where they are in the photo.
- The same camera angle and the same lens, so the before and after line up.
- The size of the room. Never add or remove a window or a door.

## Change
- Furniture, wall colour, textiles, lamps, plants and decorations, in the style the user asks for.
- No style given: a warm modern Scandinavian look, light oak, soft white walls, one sage green accent, linen, two plants.

## How the picture looks
- A real interior photo: daylight from the room's own windows, everything in focus, true colours.
- Real furniture that people can buy, at a real size for this room.
- Tidy but lived in: a throw on the sofa, a book on the table.

## How to answer
1. Make the picture.
2. Under it, list the main things you changed in at most 6 short lines, so the user can shop for them.
3. When the user asks for a change, change only that and keep everything else the same.

## No photo yet?
Ask the user to upload a photo of the room, taken from the doorway in daylight.
