---
name: painting-studio
description: Paints the user's idea as a real hand-made painting (brush marks, paint texture, paper or canvas) in one of 10 styles (classical oil, impasto, watercolor, impressionist, storybook, fantasy, art nouveau, surreal, game art, modern art). Use it when the user asks for a painting, names one of these styles, or says "paint".
---

# Painting studio

You make paintings that look truly painted by hand: brush marks, paint texture, paper or canvas. Never a photo, never clip art, never a collage.

## Pick the style
- The user names a style: use that style's section below.
- No style named: pick the one that fits the idea best, and say its name in one line under the picture.
- Most styles have a few looks. Pick one look and never mix two looks in one picture.
- The 10 styles: Classical oil, Impasto, Watercolor, Impressionist, Storybook, Fantasy, Art Nouveau, Surreal, Game art, Modern art.

## Always
- One clear subject, big in the frame, close or medium distance (small far-away details and faces come out badly).
- The paint covers the whole picture, right to every edge. No white margin, no border, no frame, and never a painting shown hanging on a wall.
- Every corner is plain paint: no painted signature, no initials, no date. No words anywhere, unless the user asks for words. Signs, books, banners, shop fronts and boats stay plain.
- Each hand does one clear thing, and anything held is held by one hand.
- Wide 16:9 unless the user asks for another shape (square, 9:16 for a phone).
- If the idea says "my" (my dog, my house) and there is no photo, paint "a dog" from the words; do not ask for a photo.
- If the user adds a photo of their pet or person, keep the face, features and markings exactly as in the photo, and paint everything else in the style.

## How to answer
1. Make the painting.
2. Under it, one line: the style you used.
3. When the user asks for a change, change only that.

## Classical oil
A real old master oil painting. Pick one look:
- Renaissance: soft smoky blends from light to shadow, a smooth panel, often a window onto a hazy blue landscape. Also pet portraits: the pet on a velvet cushion, noble, not cute.
- Dutch Golden Age: everyday scenes, still lifes and landscapes, cool daylight from a high window at the left, deep warm shadows, small crisp highlights on glass and metal.
- Baroque: one strong light against near-black darkness.
- 19th-century academic: bright, idealised, smooth skin, soft daylight.

Thin glazes over a warm toned ground, thick paint only on the brightest touches, soft edges where light turns into shadow, the background looser than the subject. Old earthy colours: lead white, ochre, umber, sienna, vermilion.

Avoid: a photo look or retouched skin (faces show warm and cool notes, a little red on the cheeks); small distant faces (they come out distorted).

## Impasto
Thick oil paint you could touch. Pick one look:
- Post-impressionist: rope-like strokes that follow the form, swirling skies, short choppy dabs for fields and leaves, dark blue outlines, chrome yellow against cobalt blue. For landscapes, night skies and towns.
- Palette knife: broad flat planes of clean colour with sharp edges. For flowers and still life.
- Expressive portrait: faces built from thick square strokes of warm and cool colour, barely blended. For people and pets.

Big simple shapes. Every stroke visible, with bristle or knife tracks in it. Thick ridges catch small glints of light where the picture matters most; the shadows are thin. Complementary colours side by side: yellow against violet, orange against blue.

Avoid: the same thickness everywhere (varied thickness reads as real paint); black shadows (use deep blue, violet or green); tiny detail.

## Watercolor
Transparent watercolor on textured cotton paper. Pick one look:
- Loose: big wet washes that bleed and mingle, a few crisp accents, lots of white paper. For landscapes, sea, sky, gardens and bouquets.
- Line and wash: quick, slightly loose black ink lines, the washes slipping outside them. For towns, streets and buildings.
- Detailed: careful layers and fine brush detail, the subject alone, fading softly into the white paper around it. For animals, people and single flowers.

Every highlight is the bare white of the paper. Soft bleeding edges sit beside crisp edges that dried with a slightly darker rim, a bloom here and there, pigment settling into the grain of the paper. Shadows are cool, see-through blue and violet. Detail only at the focal point.

Avoid: white paint or thick, opaque colour (lighter colour means more water); smooth, even washes with no blooms or hard edges.

## Impressionist
Oil painted outdoors in one sitting, a surface of separate strokes. Pick one look:
- Landscape: shimmering light on water, fields and skies, quick commas and dabs, bright colour. For landscapes, water, gardens and towns.
- Figures: people in dappled sunlight, feathery strokes, rosy skin built from touches of rose, ochre and violet. For people, portraits and pets.
- Pointillist: countless small dots of pure colour. Only when the user asks for dots.

Every stroke visible, bigger in front and smaller in the distance. Colours sit side by side unmixed, so a green field holds yellow, blue and touches of red. Forms suggested, not drawn. Reflections dragged down in short vertical strokes. No black on the palette.

Avoid: black or grey shadows (they are blue, violet and green); crisp, photographic faces (a few touches of colour); crowds of small faces (far crowds are a few dabs).

## Storybook
A children's picture-book painting in opaque, matte gouache. Pick one look:
- Cozy: soft, warm, rounded characters, lamplight and golden afternoons, coloured-pencil texture. For animals and children's scenes.
- Mid-century: 1950s and 1960s picture books, flat geometric shapes, bold pairs like hot pink with turquoise.
- Folk fairy tale: flat patterned shapes from old folk art, flowers, dots and scallops, muted earthy reds, ochres and greens. For fairy tales.

Flat colour shapes with crisp, slightly uneven hand-painted edges, a little dry-brush texture, light pencil hatching for fur and grass, a soft rosy blush on cheeks. Volume is a flat lighter side and a flat darker side. Small dot eyes. Light is a flat warm glow with soft violet or blue shadows.

Avoid: 3D shading, shine or glossy eyes; a book cover, a title page or any lettering; frightening wolves or dragons (make them friendly or mysterious).

## Fantasy
A realistic fantasy oil painting, like classic fantasy book art. Pick one look:
- Heroic: bold figures in a dramatic diagonal, warm earth tones, vivid highlights. The default.
- Epic landscape: a vast place, small figures against colossal mountains or citadels, layers fading into glowing haze.
- Dark fantasy: gothic and eerie, mist, moonlight or one torch, cold slate colours. For anything haunted.

Natural proportions and worn, real materials: dented steel, cracked leather, frayed wool. One main light, cool shadows. Loose strokes in the sky and cloaks, crisp edges only at the focal point. Distance grows lighter, cooler and softer. Earthy colours with one strong accent, such as ember orange. A dragon has four legs, two bat-like wings and a tail.

Avoid: a game, 3D render or digital art look; small distant faces (show far figures from behind); fake runes or letters on banners and shields.

## Art Nouveau
A decorative painting where ornament fills the whole picture. Pick one look:
- Art Nouveau (about 1900): a graceful figure with long flowing hair before a flat circular halo, flowers and stems in whiplash curves, flat colour in firm brown outlines, muted sage, mustard and dusty violet. The default.
- Gold leaf (Vienna, about 1907): a realistic face and hands in flat robes of gold ornament. For anything golden.
- Art Deco (1920s and 1930s): sleek figures in smooth geometric planes like polished metal, sunbursts, chevrons, one strong side light. For cars, jazz and cities.

Ornament reaches every edge. Gold is real gold leaf: overlapping squares, crinkled edges, bright here and matte there. Ornament is hand-painted, slightly irregular. Figures fully clothed.

Avoid: a border or margin; poster lettering, titles or slogans (this style tempts it most); gold as a yellow gradient; a glowing halo instead of a flat disc.

## Surreal
One impossible idea, painted calmly as a hand-made museum oil painting. Pick one look:
- Surrealist: matte opaque oil, simple softly shaded forms, deep space, a low horizon, a clear calm sky. The default.
- Pop surrealist: sweet candy colours, rounded shapes, cute creatures, sweets and toys. For anything cute or funny.
- Dreamlike: faded pastels, quiet rooms, stairs and doors leading into the sky. For anything dreamy.

The impossible thing sits in a plain, believable place. One light from one side, and every shadow falls the same way, long and sharp. Soft visible brushstrokes everywhere. Big things are painted simply: the moon a pale disc, water long strokes, the sky broad bands of colour.

Avoid: a photograph, a photo collage or a 3D render look; photo detail like every crater on the moon; melting clocks unless asked.

## Game art
Stylized, hand-painted 2D fantasy game art. Pick one look:
- Splash art: a hero or monster in action, a diagonal pose, one big magic effect. For fights and monsters.
- Character art: a calm, proud pose showing the whole design against a simple glowing background. For portraits and cute things.
- Environment: a colourful place of chunky rounded shapes, a tiny character for scale.

Proportions exaggerated on purpose: big hands, shoulders, weapons and boots, and one bold silhouette feature like a horned helm. Saturated colour, soft airbrushed gradients, crisp painted highlights, visible brushwork. A warm light on one side, a cool rim light on the other; the character is the brightest thing. Chibi means a big head and big eyes.

Avoid: a realistic, gritty or 3D render look; a woman in big armour turning into a man (keep her clearly a woman); logos, health bars or game titles.

## Modern art
A real hand-made modern painting, visible brushwork, the canvas weave showing. Pick one look:
- Cubist: flat overlapping planes seen from several sides at once, firm dark outlines, muted ochre, cream and grey. For people.
- Geometric: crystal-like planes, circles, triangles and rays of light in layered see-through colour. For cities and boats.
- Expressive: big sweeping strokes, drips and splatter, or calm fields of glowing colour. For weather, feelings and music.
- Boho: soft rounded shapes in thick acrylic, terracotta, mustard and sage: arches, a round sun, hills, plants. For landscapes.
- Fauvist: wild unnatural colour in loose bold strokes, outlines in dark blue or red, a green shadow on a face. For animals.

Keep the subject readable: its outline, its main colour, one defining feature.

Avoid: a clip-art, vector, low-poly 3D or cut-paper collage look; a canvas on a wall, a frame or a gallery.
