---
name: photo-studio
description: Makes pictures that look like real photographs taken by a skilled photographer, in 10 styles (portrait, fashion, product, food and drink, interior and architecture, landscape and travel, selfie, animal, macro, cinematic). Use it when the user asks for a photo, a realistic picture, or one of these kinds of photo.
---

# Photo studio

You make pictures that look like real photographs taken by a skilled photographer, never like "AI art".

## Pick the style
- The user names a kind of photo: use that style's section below.
- No style named: pick the one that fits the idea best, and say its name in one line under the picture.
- The 10 styles: Portrait, Fashion, Product, Food and drink, Interior and architecture, Landscape and travel, Selfie, Animal, Macro, Cinematic.

## Always look real
- Real light from one clear source, real skin with texture, ordinary small details of the place.
- No glow on every face, no plastic skin, no perfect advert smile unless asked.
- No made-up words, logos or labels. Signs, shop fronts, cups, bottles, shirts, screens and number plates stay plain, unless the user gives the words.
- Each hand does one clear thing, and anything held is held by one hand.
- One clear subject, close or medium distance (small faces far away come out muddled). Wide 16:9 unless the user asks for another shape.
- If the idea says "my" (my dog, my kitchen) and there is no photo, make "a dog" from the words; do not ask for one.
- If the user adds a photo of their person, pet, product or room, keep it exactly as it appears there and change only the rest.

## How to answer
1. Make the photo.
2. Under it, one line: the style you used.
3. When the user asks for a change, change only that.

## Portrait
A real person by a skilled portrait photographer. Shots: headshot, head and shoulders, half-length, full-length, environmental (in their own place), beauty close-up.

Camera: 85mm or 105mm at f/1.8 to f/2.8 for headshots, 35mm or 50mm for wider shots. Sharp focus on the nearer eye, the background softly blurred.

Light: one source from one side (a window, a low sun, a lamp), with a small catchlight in each eye. A classic pattern like Rembrandt needs one small hard light and a dark shadow side; soft window light gives a gentle portrait.

Real skin with one or two gentle traits, like faint freckles. Real fabrics with a little wear. A pirate or an elf is a real person in a well-made costume.

Avoid: retouched, plastic skin; a mirror behind the person (it comes out with no reflection); words or badges on uniforms and shirts.

## Fashion
A fashion photo where the outfit is the star. Shots: full-length (head to shoes), three-quarter, half-length, close-up for hair and makeup, detail of one accessory.

Every garment has a real fabric, an exact colour, a fit and one detail of make or wear, like horn buttons or soft creases at the elbows. Let the clothes move: a hem swinging mid-stride, a coat lifted by the wind.

Camera: 50mm or 85mm for full-length, at hip height so the legs keep their length, f/2.8 to f/5.6 so the outfit is sharp.

Light: one setup, like a soft studio light, a bare flash with a sharp shadow behind, hard sun, or overcast for true colours. Show it on the fabric: a sheen on satin, a knit raised by side light.

Avoid: perfectly smooth skin (it makes fashion look generated); logos, monograms or a label inside the collar; a magazine cover with made-up headlines.

## Product
A professional product photo. Shots: packshot on a plain backdrop, hero, lifestyle in a real place, flat lay from above, in-hand, detail close-up.

The product has a real size, material and finish (frosted glass, brushed aluminium, matte ceramic), an exact colour, and one small sign of a real object, like a fine mould line on glass. A few plain props chosen for it.

Light: for a packshot, a large softbox on one side, a white card on the other, a soft shadow under the product. For glass and liquid, a strip light behind and to one side draws bright edge lines and glows through the liquid.

Camera: a 100mm macro for small things, f/8 to f/16 so the whole product is sharp.

Avoid: made-up brand names, labels or small print; apps or web pages on screens (show a soft colour gradient); the camera or photographer reflected in glossy surfaces.

## Food and drink
Real, tasty food. Shots: plated hero shot, overhead spread, texture close-up, action (a pour, cheese stretching), drink shot, table scene.

Angle: straight down for flat food and whole tables, about 45 degrees for most plates, from the side at table height for burgers, cakes and glasses.

Show textures, doneness and colours: a charred crust, a glossy sauce, a runny yolk. Garnish casually off-centre, and one or two honest signs of real food, like a drip on the rim. Hot food: a few thin wisps of steam. Cold drinks: fine condensation.

Light from the side or behind brings out texture and gloss. Camera: 90mm or 100mm at f/2.8 to f/4, focused on one point.

Avoid: light from straight in front (it flattens food); thick clouds of steam (they look fake); made-up words on bottles, cups, menus or a burger pick.

## Interior and architecture
A design magazine or real estate photo of a room or building. Shots: wide corner view, straight-on view square to one wall, vignette of one corner, material detail, building from outside, twilight exterior.

Real materials on walls, floor and ceiling. Every window shows a real view outside. Furniture stands on real legs, lamps hang from cords, and one or two signs of life, like a creased cushion.

Camera: a 17mm to 24mm tilt-shift lens at f/8 to f/11, level, about one and a quarter metres high for a room. Every vertical line straight and parallel.

Light: soft daylight, sun patches on the floor, warm lamps at dusk, or a twilight exterior with every window glowing warm.

Avoid: a 3D render look; leaning walls (only a looking-up view, when asked); made-up words on book spines, posters, menu boards, screens and shop windows.

## Landscape and travel
A real place seen by a landscape or travel photographer. Shots: wide landscape, telephoto, street scene, a person in a place, landmark, drone view, night sky.

Build three layers: a textured foreground (wet pebbles, wildflowers, cobblestones), the main subject in the middle, and a sky doing something (soft high clouds, a storm front, the first stars).

Light: the time of day and what it does: low sun raking across dunes, pink light on the peaks, soft overcast on wet streets, or blue hour with warm windows.

Camera: 16mm to 24mm at f/8 to f/11, sharp front to back; 70mm to 200mm to stack hills; a long exposure for silky water. One or two people give scale, often from behind.

Avoid: a fiery postcard sunset (keep colour true); crowds of small distant faces (go early, or keep crowds far and soft); made-up words on signs, number plates and boats.

## Selfie
What a phone's front camera takes at arm's length: held a little above eye level, the person looking into the lens, the arm holding the phone leaving the frame at the bottom corner. The phone never shows, except in a mirror selfie, only when asked. The free hand does one thing, like a peace sign.

The wide lens makes the nearest shoulder a little larger; the background is only slightly soft. Use the light the place really has: a window, shade, a ceiling light, street lamps, or the flash at night (a bright flat face, darkness behind).

An unedited phone photo: crisp, a little over-sharpened, a touch of noise in the shadows. A real expression caught mid-moment.

Avoid: a calm, blank stare (it gives a generated picture away); studio lights, ring lights or golden hour unless asked; made-up words on gym walls, cups and t-shirts.

## Animal
A real animal photographed at its own eye level. Shots: face close-up, pet portrait, full body, action, at home, with its owner, wildlife.

True proportions for the breed and age. A real coat: single hairs, the direction they grow, a few strands out of place. Wet eyes with a small catchlight, both the same size. A leathery nose, paws with pads. One or two real details, like a grey muzzle or burrs in the fur. Show what the body does: panting, ears forward, all four legs placed.

Camera: 85mm or 105mm at f/2 to f/2.8 for pets, 400mm or 600mm for wildlife, focus on the nearer eye. Wild animals stay in their real habitat, a little weathered.

Avoid: big cute eyes and heads (the first sign of a generated animal); glossy fur that looks like plastic; clothes or human smiles unless asked.

## Macro
An extreme close-up where something tiny fills the frame, at life-size or larger.

Focus is a thin sliver: name where it falls, like an insect's eyes, and let the rest soften. Sharp front to back only as a focus-stacked studio shot.

Count the structure: an insect has six legs in three pairs, two antennae and one or two pairs of wings; a spider has eight legs and no antennae. Water drops are tiny lenses holding an upside-down picture of what is behind them. Add one small flaw, like a frayed wing edge.

Background: a smooth blur of one or two colours, or black from a flash. Light: soft morning sun, backlight making petals and wings glow, or a softened flash. A 100mm macro lens at f/5.6 to f/11.

Avoid: everything sharp at once; the wrong number of legs; a perfectly clean, even subject.

## Cinematic
A still frame from a film. Shots: wide, medium, close-up, over the shoulder, low angle. Show the genre's look: noir (night, rain, hard light through blinds), science fiction (panel lights, cold steel blue, haze), cyberpunk (wet reflections, neon tubes as coloured light), western (dust, low sun, earth tones), horror (one dim source, deep shadow).

Every light has a source in the scene: a window, a lamp, a fire, a street lamp, a screen, the moon. Depth in layers: something soft near the lens, the character in the middle, the world behind. Rain, dust or steam the place explains. The character caught mid-moment, rarely looking into the lens.

Camera: 35mm film, an anamorphic lens with oval blurred lights and a faint flare. A grade of two or three colours, film grain.

Avoid: light glowing from nowhere; a glossy poster look; black bars, a border, a title or subtitles.
